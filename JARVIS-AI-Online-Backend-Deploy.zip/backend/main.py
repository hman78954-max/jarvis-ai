"""
JARVIS AI backend: a thin, authenticated proxy between the Android app and the model API.

The model API key lives ONLY here (ANTHROPIC_API_KEY). The app sends a system prompt + messages
and receives the model's text (a JSON plan or an answer). Web search runs server-side so answers
about current events come from real sources, not from the model's memory.
"""
import hmac
import ipaddress
import os
import re
import socket
import time
import hashlib
from collections import defaultdict, deque
from html.parser import HTMLParser
from typing import List, Literal, Optional
from urllib.parse import urljoin, urlparse

import httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

MODEL = os.environ.get("JARVIS_MODEL", "claude-sonnet-5-5")
TOKEN = os.environ.get("JARVIS_BACKEND_TOKEN", "")
RATE_PER_MINUTE = int(os.environ.get("JARVIS_RATE_PER_MINUTE", "30"))
MAX_PAYLOAD_CHARS = int(os.environ.get("JARVIS_MAX_PAYLOAD_CHARS", "4_000_000"))
MAX_FETCH_BYTES = int(os.environ.get("JARVIS_MAX_FETCH_BYTES", "1_000_000"))
MAX_FETCH_TEXT = int(os.environ.get("JARVIS_MAX_FETCH_TEXT", "12_000"))
MAX_URLS_PER_REQUEST = int(os.environ.get("JARVIS_MAX_URLS_PER_REQUEST", "2"))

app = FastAPI(title="JARVIS AI backend")
_client = None
_hits = defaultdict(deque)


def get_client():
    global _client
    if _client is None:
        from anthropic import AsyncAnthropic

        _client = AsyncAnthropic()  # reads ANTHROPIC_API_KEY
    return _client


class Block(BaseModel):
    type: Literal["text", "image", "document"]
    text: Optional[str] = None
    media_type: Optional[str] = None
    data: Optional[str] = None


class Msg(BaseModel):
    role: Literal["user", "assistant"]
    content: List[Block]


class AssistantRequest(BaseModel):
    system: str
    messages: List[Msg]


def check_auth(authorization: Optional[str]) -> str:
    if not TOKEN:
        raise HTTPException(500, "Backend not configured: set JARVIS_BACKEND_TOKEN.")
    expected = f"Bearer {TOKEN}"
    if not authorization or not hmac.compare_digest(authorization, expected):
        raise HTTPException(401, "Unauthorized")
    return authorization


def check_rate(key: str) -> None:
    # Store only a one-way identifier, never the bearer token itself.
    bucket = hashlib.sha256(key.encode("utf-8")).hexdigest()
    now = time.time()
    q = _hits[bucket]
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= RATE_PER_MINUTE:
        raise HTTPException(429, "Too many requests, slow down.")
    q.append(now)


class _Text(HTMLParser):
    def __init__(self):
        super().__init__()
        self.skip = 0
        self.parts: List[str] = []

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "noscript"):
            self.skip += 1

    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript") and self.skip:
            self.skip -= 1

    def handle_data(self, data):
        if not self.skip and data.strip():
            self.parts.append(data.strip())


def _public_host(host: str) -> bool:
    try:
        for info in socket.getaddrinfo(host, None):
            ip = ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
                return False
        return True
    except Exception:
        return False


async def fetch_page_text(url: str, limit: int = MAX_FETCH_TEXT) -> Optional[str]:
    """Fetch a bounded public text page while re-checking every redirect target."""
    headers = {"User-Agent": "JARVIS-Backend/1.1", "Accept": "text/html,text/plain;q=0.9,*/*;q=0.1"}
    timeout = httpx.Timeout(connect=5.0, read=10.0, write=10.0, pool=5.0)
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=False) as http:
        for _ in range(4):
            p = urlparse(url)
            if p.scheme not in ("http", "https") or not p.hostname or p.username or p.password:
                return None
            if not _public_host(p.hostname):
                return None
            try:
                async with http.stream("GET", url, headers=headers) as r:
                    if r.is_redirect and r.headers.get("location"):
                        url = urljoin(url, r.headers["location"])
                        continue
                    if r.status_code != 200 or "text" not in r.headers.get("content-type", "").lower():
                        return None
                    declared = r.headers.get("content-length")
                    if declared and int(declared) > MAX_FETCH_BYTES:
                        return None
                    chunks = []
                    total = 0
                    async for chunk in r.aiter_bytes():
                        total += len(chunk)
                        if total > MAX_FETCH_BYTES:
                            return None
                        chunks.append(chunk)
                    parser = _Text()
                    parser.feed(b"".join(chunks).decode(r.encoding or "utf-8", errors="replace"))
                    return " ".join(parser.parts)[:limit]
            except (httpx.HTTPError, ValueError):
                return None
    return None


URL_RE = re.compile(r"https?://[^\s)>\"']+")


def to_api_messages(msgs: List[Msg]):
    out = []
    for m in msgs:
        blocks = []
        for b in m.content:
            if b.type == "text":
                blocks.append({"type": "text", "text": b.text or ""})
            elif b.type == "image" and b.data and b.media_type in ("image/jpeg", "image/png", "image/webp", "image/gif"):
                blocks.append({"type": "image", "source": {"type": "base64", "media_type": b.media_type, "data": b.data}})
            elif b.type == "document" and b.data and b.media_type == "application/pdf":
                blocks.append({"type": "document", "source": {"type": "base64", "media_type": b.media_type, "data": b.data}})
        if blocks:
            out.append({"role": m.role, "content": blocks})
    return out


@app.get("/health")
async def health():
    return {"ok": True, "model": MODEL}


@app.post("/v1/assistant")
async def assistant(req: AssistantRequest, authorization: Optional[str] = Header(default=None)):
    key = check_auth(authorization)
    check_rate(key)
    if len(req.messages) > 40 or len(req.system) > 30_000:
        raise HTTPException(413, "Request too large.")
    if sum(len(b.data or "") + len(b.text or "") for m in req.messages for b in m.content) > MAX_PAYLOAD_CHARS:
        raise HTTPException(413, "Attachments too large.")

    msgs = to_api_messages(req.messages)
    if not msgs or msgs[-1]["role"] != "user":
        raise HTTPException(400, "The last message must come from the user.")

    # Summarise pages: fetch URLs the user pasted (public pages only) and hand the text to the model.
    last_text = " ".join(b["text"] for b in msgs[-1]["content"] if b["type"] == "text")
    extras = []
    for url in URL_RE.findall(last_text)[:MAX_URLS_PER_REQUEST]:
        page = await fetch_page_text(url)
        if page:
            extras.append(f"[Fetched content of {url}]\n{page}")
    if extras:
        msgs[-1]["content"].append({"type": "text", "text": "\n\n" + "\n\n".join(extras)})

    client = get_client()
    kwargs = dict(model=MODEL, max_tokens=2000, system=req.system, messages=msgs)
    try:
        resp = await client.messages.create(
            **kwargs, tools=[{"type": "web_search_20250305", "name": "web_search", "max_uses": 3}]
        )
    except Exception as e:  # web search unavailable for this account/model: fall back to plain answers
        if "web_search" in str(e) or "tool" in str(e).lower():
            resp = await client.messages.create(**kwargs)
        else:
            raise HTTPException(502, f"Model request failed: {type(e).__name__}")
    text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text").strip()
    if not text:
        raise HTTPException(502, "The model returned no text.")
    return {"text": text}
