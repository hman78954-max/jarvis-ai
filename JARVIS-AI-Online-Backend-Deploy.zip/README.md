# JARVIS AI — Online Backend Deployment Package

This package contains only the authenticated FastAPI backend needed to put JARVIS online.
It is intentionally separate from the Android app.

## What it provides

- `GET /health` health endpoint
- `POST /v1/assistant` authenticated AI endpoint
- Server-side Anthropic API key handling
- Optional server-side web search through the model provider
- Bounded public URL fetching for URLs pasted into user messages
- Redirect limits and private-network blocking
- Bearer authentication
- Per-token rate limiting
- Request/attachment size limits

## Secrets

Never commit these values:

- `JARVIS_BACKEND_TOKEN`
- `ANTHROPIC_API_KEY`

Set them as environment variables in the hosting provider.

## Render

This package includes `render.yaml` and `Dockerfile`.
Create a Render web service from the repository containing these files. Render will use the Dockerfile and the `/health` endpoint.

After deployment, the public service URL will look like:
`https://jarvis-ai-backend.onrender.com`

The Android app should use that HTTPS URL as its backend base URL.

## Local verification

```bash
pip install -r backend/requirements.txt
uvicorn backend.main:app --host 0.0.0.0 --port 10000
```

Then open `/health`.

## Important

The backend cannot access private accounts, bypass logins, or control arbitrary devices. Android-side accessibility/device actions remain permission-gated in the app.
